import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-diary',
  templateUrl: './stock-diary.component.html',
  styleUrls: ['./stock-diary.component.css']
})
export class StockDiaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
