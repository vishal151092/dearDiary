import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-entry',
  templateUrl: './add-entry.component.html',
  styleUrls: ['./add-entry.component.css']
})
export class AddEntryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  saveEntry() {
  //save method called
  }

}
